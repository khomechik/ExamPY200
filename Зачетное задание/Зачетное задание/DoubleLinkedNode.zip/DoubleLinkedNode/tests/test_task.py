import unittest

from task import Node


# todo: replace this with an actual test
class TestCase(unittest.TestCase):
    def test_is_valid(self):
        ...
        # node = Node(None)
        #
        # msg = f"Метод is_valid должен генерировать ошибку \"TypeError\", " \
        #       f"если тип проверяемого объекта не \"{Node.__name__}\" или не \"{type(None).__name__}"
        # with self.assertRaises(TypeError, msg=msg):
        #     node.is_valid("incorrect_type")

    def test_init_node(self):
        # todo init node with next and without
        ...

    def test_set_next(self):
        # todo test set next
        ...
